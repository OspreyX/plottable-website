function makeCustomProjectorChart() {
  var xScale = new Plottable.Scale.Linear();
  var yScale = new Plottable.Scale.Linear();

  var xAxis = new Plottable.Axis.Numeric(xScale, "bottom");
  var yAxis = new Plottable.Axis.Numeric(yScale, "left");
  var plot = new Plottable.Plot.Line(xScale, yScale);
  plot.addDataset(gitData);

  function getXDataValue(d) {
    return d.day;
  }
  plot.project("x", getXDataValue, xScale);

  function getYDataValue(d) {
    return d.total_commits;
  }
  plot.project("y", getYDataValue, yScale);

  var chart = new Plottable.Component.Table([
                    [yAxis, plot],
                    [null,  xAxis   ]
                  ]);

  chart.renderTo("#customProjectorChart");
}
