function makeNestedTables() {

  var xScale = new Plottable.Scale.Linear();
  var xAxis = new Plottable.Axis.Numeric(xScale, "bottom");
  var yScale = new Plottable.Scale.Linear();
  var yAxis = new Plottable.Axis.Numeric(yScale, "left");
  var linePlot = new Plottable.Plot.Line(xScale, yScale);
  linePlot.addDataset(gitData);

  function getDayValue(d) {
    return d.day;
  }
  linePlot.project("x", getDayValue, xScale);

  function getTotalCommits(d) {
    return d.total_commits;
  }
  linePlot.project("y", getTotalCommits, yScale);

  var title = new Plottable.Component.TitleLabel("Plottable Git Data");
  var subtitle = new Plottable.Component.Label("Total Commits, by day, to the Plottable repo");
  var titleTable = new Plottable.Component.Table([
                    [title],
                    [subtitle]
                  ]);
  titleTable.xAlign("center");

  var dataTable = new Plottable.Component.Table([
                    [yAxis, linePlot],
                    [null, xAxis]
                  ]);

  var chart = new Plottable.Component.Table([
                    [titleTable],
                    [dataTable]
                  ]);

  chart.renderTo("#chart");
}
