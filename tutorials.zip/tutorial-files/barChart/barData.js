//population, in millions
barData = [
	{
		country: "China",
		population: 1365
	},
	{
		country: "The Republic of India",
		population: 1237
	},
	{
		country: "United States of America",
		population: 313
	},
	{
		country: "Indonesia",
		population: 247
	},
	{
		country: "Brazil",
		population: 199
	}
];
