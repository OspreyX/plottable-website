function makeBarChart() {
  var xScale = new Plottable.Scale.Linear();
  var xAxis = new Plottable.Axis.Numeric(xScale, "bottom");
  var yScale = new Plottable.Scale.Ordinal();
  var yAxis = new Plottable.Axis.Category(yScale, "left");
  var barPlot = new Plottable.Plot.Bar(xScale, yScale, false);
  barPlot.addDataset(barData);
  barPlot.project("y", "country", yScale);
  barPlot.project("x", "population", xScale);

  var title = new Plottable.Component.TitleLabel("Population of Countries (millions)");

  var dataTable = new Plottable.Component.Table([
                    [yAxis, barPlot],
                    [null, xAxis]
                  ]);

  var chart = new Plottable.Component.Table([
                    [title],
                    [dataTable]
                  ]);

  chart.renderTo("#chart");
}
