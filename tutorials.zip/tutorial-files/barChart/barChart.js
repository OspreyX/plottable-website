function makeBarChart() {
  var xScale = new Plottable.Scale.Ordinal();
  var yScale = new Plottable.Scale.Linear();
  var xAxis = new Plottable.Axis.Category(xScale, "bottom");
  var yAxis = new Plottable.Axis.Numeric(yScale, "left");
  var barPlot = new Plottable.Plot.Bar(xScale, yScale, true);
  barPlot.addDataset(barData);
  barPlot.project("x", "country", xScale);
  barPlot.project("y", "population", yScale);

  var title = new Plottable.Component.TitleLabel("Population of Countries (millions)");

  var dataTable = new Plottable.Component.Table([
                    [yAxis, barPlot],
                    [null, xAxis]
                  ]);

  var chart = new Plottable.Component.Table([
                    [title],
                    [dataTable]
                  ]);

  chart.renderTo("#chart");
}
